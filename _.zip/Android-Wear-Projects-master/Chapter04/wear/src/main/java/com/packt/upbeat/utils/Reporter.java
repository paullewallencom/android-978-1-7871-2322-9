package com.packt.upbeat.utils;

/**
 * Created by ashok.kumar on 20/05/17.
 */


public interface Reporter {
    public void notifyEvent(Object o);
}
