package com.packt.smartchat;

/**
 * Created by ashok.kumar on 14/05/17.
 */

public class User {
    static String username = "";
    static String password = "";
    static String chatWith = "";
}
