package com.packt.upbeat.utils;

/**
 * Created by ashok.kumar on 28/05/17.
 */

public class CaloryItem {

    public String Calories;

    public CaloryItem(String calories) {
        Calories = calories;
    }

    public String getCalories() {
        return Calories;
    }

    public void setCalories(String calories) {
        Calories = calories;
    }
}
