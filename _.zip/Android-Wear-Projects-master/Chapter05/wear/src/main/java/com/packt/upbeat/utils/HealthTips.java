package com.packt.upbeat.utils;

/**
 * Created by ashok.kumar on 28/05/17.
 */

public class HealthTips {

   public static String[] nameArray =
           {"Food style",
                   "Food style",
                   "Food style",
                   "Drinking water",
                   "Unhealthy drinks",
                   "Alcohol and drugs",
                   "Body Mass index",
                   "Physical excercise",
                   "Physical activities",
                   "Meditation",
                   "Healthy signs"};

    public static String[] versionArray = {
            "Along with fresh vegetables and fruits, eat lean meats (if you’re not vegetarian), nuts, and seeds.",
            "Opt for seasonal and local products instead of those exotic imported foodstuff",
            "Make sure you get a proper balanced diet, as often as possible",
            "Drink water – you need to stay hydrated. It is great for your internal organs, and it also keeps your skin healthy and diminishes acne",
            "Stop drinking too much caffeine and caffeinated beverages",
            "Limit alcohol intake. Tobacco and drugs should be a firm No",
            "Maintain a healthy weight.",
            "Exercise at least four days a week for 20 to 30 minutes each day. Another option is to break your workouts into several sessions",
            "Try to have as much physical activity as you can. Take the stairs instead of elevator; walk to the market instead of taking your car etc",
            "Practice simple meditation. It balances your body, mind, and soul",
    "When speaking about health tips, skin, teeth, hair, and nails are all health signs. Loss of hair or fragile nails might mean poor nutrition"};

}
