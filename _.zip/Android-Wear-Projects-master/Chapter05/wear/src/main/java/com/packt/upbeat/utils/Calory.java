package com.packt.upbeat.utils;

/**
 * Created by ashok.kumar on 28/05/17.
 */

public class Calory {

    public static String[] nameArray =
            {"Apple, medium: 72",
                    "Bagel: 289", "Banana, medium: 105",

                    "Beer (regular, 12 ounces): 153",

                    "Bread (one slice, wheat or white): 66",

                    "Butter (salted, 1 tablespoon): 1",
                    "Carrots (raw, 1 cup): 52",

                    "Cheddar cheese (1 slice): 113",

                    "Chicken breast (boneless, skinless, roasted, 3 ounces): 142",

                    "Chili with beans (canned, 1 cup): 287",

                    "Chocolate chip cookie (from packaged dough): 59",

                    "Coffee (regular, brewed from grounds, black): 2",

                    "Cola (12 ounces): 136",

                    "Corn (canned, sweet yellow whole kernel, drained, 1 cup): 180",

                    "Egg (large, scrambled): 102",

                    "Graham cracker (plain, honey, or cinnamon): 59",

                    "Granola bar (chewy, with raisins, 1.5-ounce bar): 193",

                    "Green beans (canned, drained, 1 cup): 40",

                    "Ground beef patty 193 (15 percent fat, 4 ounces, pan-broiled):",

                    "Hot dog (beef and pork): 137",

                    "Ice cream (vanilla, 4 ounces): 145",

                    "Jelly doughnut: 289",

                    "Ketchup (1 tablespoon): 15",

                    "Milk (2 percent milk fat, 8 ounces): 122",

                    "Mixed nuts (dry roasted, with peanuts, salted, 1 ounce): 168",

                    "Mustard, yellow (2 teaspoons): 6",

                    "Oatmeal (plain, cooked in water without salt, 1 cup): 147",

                    "Orange juice (frozen concentrate, made with water, 8 ounces): 112",

                    "Peanut butter (creamy, 2 tablespoons): 180",

                    "Pizza (pepperoni, regular crust, one slice): 298",

                    "Pork chop (center rib, boneless, broiled, 3 ounces): 221",

                    "Potato, medium (baked, including skin): 161",

                    "Potato chips (plain, salted, 1 ounce): 155",

                    "Pretzels (hard, plain, salted, 1 ounce): 108",

                    "Raisins (1.5 ounces): 130",

                    "Ranch salad dressing (2 tablespoons): 146",

                    "Red wine (cabernet sauvignon, 5 ounces): 123",

                    "Rice (white, long grain, cooked, 1 cup): 205",

                    "Salsa (4 ounces): 35",

                    "Shrimp (cooked under moist heat, 3 ounces): 84",

                    "Spaghetti (cooked, enriched, without added salt, 1 cup): 221",

                    "Spaghetti sauce (marinara, ready to serve, 4 ounces): 92",

                    "Tuna (light, canned in water, drained, 3 ounces): 100",

                    "White wine (sauvignon blanc, 5 ounces): 121",

                    "Yellow cake with chocolate frosting (one piece): 243"

            };
}
